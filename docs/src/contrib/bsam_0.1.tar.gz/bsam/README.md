# bsam

A Bayesian structural after measurement approach. Under development.

bsam is supported by the Institute of Education Sciences, U.S. Department of Education, Grant R305D210044.
